package com.example.mindquest

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PuzzlesTest {

    private val allBanks = PuzzleBank.riddles + PuzzleBank.logic + PuzzleBank.math + PuzzleBank.premium

    @Test
    fun everyMainAnswerIsAccepted() {
        allBanks.forEach { p -> assertTrue(p.text, Answers.isCorrect(p.mainAnswer, p)) }
    }

    @Test
    fun answerCheckIgnoresCaseYoAndPunctuation() {
        val p = Puzzle("?", listOf("ёлка", "ель"), "")
        assertTrue(Answers.isCorrect("  Елка! ", p))
        assertTrue(Answers.isCorrect("это ель", p))
        assertFalse(Answers.isCorrect("сосна", p))
    }

    @Test
    fun latinTransliterationIsAccepted() {
        val p = Puzzle("?", listOf("ёлка", "расчёска", "огурец", "семья", "я"), "")
        listOf("elka", "Yolka", "raschyoska", "ogurets", "semya", "sem'ya", "ya", "eto elka")
            .forEach { assertTrue(it, Answers.isCorrect(it, p)) }
        assertFalse(Answers.isCorrect("sosna", p))
    }

    @Test
    fun numericAnswers() {
        val p = Puzzle("?", listOf("0.75"), "")
        assertTrue(Answers.isCorrect("0,75", p))
        assertTrue(Answers.isCorrect("ответ: 0.750", p))
        assertFalse(Answers.isCorrect("75", p))
    }

    @Test
    fun levelsHaveTenUniqueQuestionsAndAreStable() {
        for (cat in listOf(Category.RIDDLES, Category.LOGIC, Category.MATH, Category.PREMIUM)) {
            for (lvl in 1..30) {
                val a = PuzzleBank.level(cat, lvl)
                assertEquals(Game.QUESTIONS_PER_LEVEL, a.size)
                assertEquals(a.map { it.text }, PuzzleBank.level(cat, lvl).map { it.text })
                a.forEach { p -> assertTrue(p.text, Answers.isCorrect(p.mainAnswer, p)) }
            }
        }
    }
}
