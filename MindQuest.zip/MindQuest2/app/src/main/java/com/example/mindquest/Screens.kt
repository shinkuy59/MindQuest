package com.example.mindquest

import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Paint
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.util.Patterns
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ───────────── Вспомогательные функции ─────────────

/** Подчёркивает «ссылочные» тексты, как в макете. */
private fun TextView.underline() { paintFlags = paintFlags or Paint.UNDERLINE_TEXT_FLAG }

private inline fun <reified T : AppCompatActivity> Context.go() =
    startActivity(Intent(this, T::class.java))

/** Открывает экран и очищает стек (после входа/выхода). */
private inline fun <reified T : AppCompatActivity> Context.goClear() =
    startActivity(Intent(this, T::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK))

private fun Context.toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

private fun Context.dp(v: Int) = (v * resources.displayMetrics.density).toInt()

private fun Context.color(id: Int) = ContextCompat.getColor(this, id)

private fun ImageView.tint(color: Int) { imageTintList = ColorStateList.valueOf(color) }

private fun Context.dialog() = MaterialAlertDialogBuilder(this)

private fun formatDate(ms: Long): String =
    SimpleDateFormat("dd.MM.yyyy", Locale.forLanguageTag("ru")).format(Date(ms))

private fun Context.field(hint: String, type: Int, value: String = "") = EditText(this).apply {
    this.hint = hint
    inputType = type
    setText(value)
    setSingleLine()
    setTextColor(color(R.color.white))
    setHintTextColor(color(R.color.text_muted))
}

private fun Context.form(vararg views: View): View = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    setPadding(dp(24), dp(8), dp(24), 0)
    views.forEach { addView(it) }
}

private val TYPE_EMAIL = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
private val TYPE_PASSWORD = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
private val TYPE_NAME = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PERSON_NAME or InputType.TYPE_TEXT_FLAG_CAP_WORDS

private fun validEmail(s: String) = Patterns.EMAIL_ADDRESS.matcher(s).matches()

// ───────────── Приветствие ─────────────

class WelcomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.current != null) { goClear<HomeActivity>(); finish(); return }
        setContentView(R.layout.activity_welcome)
        findViewById<TextView>(R.id.tvRegister).apply { underline(); setOnClickListener { go<RegisterActivity>() } }
        findViewById<TextView>(R.id.btnStart).setOnClickListener { go<RegisterActivity>() }
        findViewById<TextView>(R.id.btnLogin).setOnClickListener { go<LoginActivity>() }
    }
}

// ───────────── Вход ─────────────

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPass = findViewById<EditText>(R.id.etPassword)

        findViewById<TextView>(R.id.tvForgot).apply { underline(); setOnClickListener { forgot(etEmail.text.toString()) } }
        findViewById<TextView>(R.id.tvRegister).apply { underline(); setOnClickListener { go<RegisterActivity>(); finish() } }
        findViewById<View>(R.id.btnGoogle).setOnClickListener {
            toast("Вход через Google появится после подключения Firebase. Используйте имейл.")
        }
        findViewById<TextView>(R.id.btnLogin).setOnClickListener {
            val email = etEmail.text.toString().trim()
            val pass = etPass.text.toString()
            when {
                !validEmail(email) -> etEmail.error = "Введите корректный имейл"
                pass.isEmpty() -> etPass.error = "Введите пароль"
                Store.find(email) == null -> etEmail.error = "Аккаунт не найден. Зарегистрируйтесь"
                !Store.login(email, pass) -> etPass.error = "Неверный пароль"
                else -> {
                    toast("С возвращением, ${Store.current?.name}!")
                    goClear<HomeActivity>()
                }
            }
        }
    }

    private fun forgot(prefill: String) {
        val email = field("Имейл", TYPE_EMAIL, prefill.trim())
        val pass = field("Новый пароль (мин. 6 символов)", TYPE_PASSWORD)
        dialog().setTitle("Восстановление пароля")
            .setView(form(email, pass))
            .setPositiveButton("Сохранить") { _, _ ->
                val e = email.text.toString().trim(); val p = pass.text.toString()
                when {
                    !validEmail(e) -> toast("Некорректный имейл")
                    p.length < 6 -> toast("Пароль слишком короткий")
                    Store.resetPassword(e, p) -> toast("Пароль изменён. Теперь войдите")
                    else -> toast("Аккаунт с таким имейлом не найден")
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }
}

// ───────────── Регистрация ─────────────

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)
        val etName = findViewById<EditText>(R.id.etName)
        val etEmail = findViewById<EditText>(R.id.etEmail)
        val etPass = findViewById<EditText>(R.id.etPassword)

        findViewById<TextView>(R.id.tvLogin).apply { underline(); setOnClickListener { go<LoginActivity>(); finish() } }
        findViewById<View>(R.id.btnGoogle).setOnClickListener {
            toast("Регистрация через Google появится после подключения Firebase. Используйте имейл.")
        }
        findViewById<TextView>(R.id.btnRegister).setOnClickListener {
            val name = etName.text.toString().trim()
            val email = etEmail.text.toString().trim()
            val pass = etPass.text.toString()
            when {
                name.length < 2 -> etName.error = "Введите имя (минимум 2 символа)"
                name.length > 20 -> etName.error = "Имя слишком длинное (максимум 20)"
                !validEmail(email) -> etEmail.error = "Введите корректный имейл"
                pass.length < 6 -> etPass.error = "Пароль — минимум 6 символов"
                else -> {
                    val err = Store.register(name, email, pass)
                    if (err != null) etEmail.error = err
                    else { toast("Аккаунт создан!"); goClear<HomeActivity>() }
                }
            }
        }
    }
}

// ───────────── Главная ─────────────

class HomeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.current == null) { goClear<WelcomeActivity>(); finish(); return }
        setContentView(R.layout.activity_home)

        findViewById<TextView>(R.id.btnPlay).setOnClickListener {
            val u = Store.current ?: return@setOnClickListener
            QuestionActivity.start(this, if (Game.dailyDone(u)) Category.RIDDLES else Category.DAILY)
        }
        findViewById<View>(R.id.cardRiddles).setOnClickListener { QuestionActivity.start(this, Category.RIDDLES) }
        findViewById<View>(R.id.cardLogic).setOnClickListener { QuestionActivity.start(this, Category.LOGIC) }
        findViewById<View>(R.id.cardMath).setOnClickListener { QuestionActivity.start(this, Category.MATH) }
        findViewById<View>(R.id.cardPremium).setOnClickListener {
            if (Store.current?.isPremium == true) QuestionActivity.start(this, Category.PREMIUM)
            else go<PremiumActivity>()
        }
        findViewById<View>(R.id.headerGreeting).setOnClickListener { go<ProfileActivity>() }
        findViewById<View>(R.id.tvLives).setOnClickListener {
            val u = Store.current ?: return@setOnClickListener
            when {
                u.isPremium -> toast("Премиум: безлимитные попытки")
                u.lives >= Game.MAX_LIVES -> toast("Все жизни на месте")
                else -> toast("Новая жизнь через ${Game.formatMs(Game.msToNextLife(u))}")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        val u = Store.current ?: return
        Game.refreshLives(u)
        Game.touchStreak(u)
        Store.save(u)

        findViewById<TextView>(R.id.tvGreeting).text = getString(R.string.t_privet_format, u.name)
        findViewById<TextView>(R.id.tvLives).text = if (u.isPremium) "∞" else u.lives.toString()
        findViewById<TextView>(R.id.tvStars).text = u.stars.toString()

        val done = Game.dailyDone(u)
        findViewById<TextView>(R.id.tvDailyTitle).text = if (done) "Загадка дня решена ✓" else "Загадка дня"
        findViewById<TextView>(R.id.tvDailySub).text =
            if (done) "Новая загадка завтра. Продолжайте играть!" else "Награда х2 за сегодня"

        findViewById<TextView>(R.id.tvRiddlesLvl).text = "Уровень ${u.currentLevel(Category.RIDDLES)}"
        findViewById<TextView>(R.id.tvLogicLvl).text = "Уровень ${u.currentLevel(Category.LOGIC)}"
        findViewById<TextView>(R.id.tvMathLvl).text = "Уровень ${u.currentLevel(Category.MATH)}"

        val card = findViewById<View>(R.id.cardPremium)
        val icon = findViewById<ImageView>(R.id.ivPremiumIcon)
        val title = findViewById<TextView>(R.id.tvPremiumTitle)
        val lvl = findViewById<TextView>(R.id.tvPremiumLvl)
        if (u.isPremium) {
            card.setBackgroundResource(R.drawable.bg_card)
            icon.setImageResource(R.drawable.ic_crown); icon.tint(color(R.color.yellow))
            title.text = "Эксклюзив"; title.setTextColor(color(R.color.white))
            lvl.text = "Уровень ${u.currentLevel(Category.PREMIUM)}"
        } else {
            card.setBackgroundResource(R.drawable.bg_card_locked)
            icon.setImageResource(R.drawable.ic_lock); icon.tint(color(R.color.text_muted))
            title.text = getString(R.string.t_premium); title.setTextColor(color(R.color.text_muted))
            lvl.text = "Открыть"
        }
    }
}

// ───────────── Профиль ─────────────

class ProfileActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.current == null) { goClear<WelcomeActivity>(); finish(); return }
        setContentView(R.layout.activity_profile)
        findViewById<View>(R.id.rowPremium).setOnClickListener { go<PremiumActivity>() }
        findViewById<View>(R.id.rowAchievements).setOnClickListener { showAchievements() }
        findViewById<View>(R.id.rowSettings).setOnClickListener { showSettings() }
        findViewById<TextView>(R.id.tvLogout).setOnClickListener {
            dialog().setTitle("Выйти из аккаунта?")
                .setMessage("Ваш прогресс сохранится — войдите снова, чтобы продолжить.")
                .setPositiveButton("Выйти") { _, _ -> Store.logout(); goClear<WelcomeActivity>() }
                .setNegativeButton("Отмена", null).show()
        }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val u = Store.current ?: return
        findViewById<TextView>(R.id.tvAvatar).text = u.name.take(1).uppercase()
        findViewById<TextView>(R.id.tvName).text = u.name
        findViewById<TextView>(R.id.tvEmail).text = u.email
        findViewById<TextView>(R.id.tvLevelValue).text = u.totalLevel.toString()
        findViewById<TextView>(R.id.tvStarsValue).text = u.stars.toString()
        findViewById<TextView>(R.id.tvStreakValue).text = u.streak.toString()
        val unlocked = Game.achievements.count { it.unlocked(u) }
        findViewById<TextView>(R.id.tvAchCount).text = "$unlocked/${Game.achievements.size}"
        findViewById<TextView>(R.id.tvPremiumStatus).text =
            if (u.isPremium) "до ${formatDate(u.premiumUntil)}" else "не активен"
    }

    private fun showAchievements() {
        val u = Store.current ?: return
        val text = Game.achievements.joinToString("\n\n") {
            (if (it.unlocked(u)) "✅ " else "🔒 ") + it.title + "\n" + it.desc
        }
        val stats = "\n\nРешено задач: ${u.solved}\nВсего заработано звёзд: ${u.totalStars}\n" +
            "Лучшая серия: ${u.bestStreak} дн.\nИспользовано подсказок: ${u.hintsUsed}"
        dialog().setTitle("Достижения").setMessage(text + stats).setPositiveButton("ОК", null).show()
    }

    private fun showSettings() {
        val items = arrayOf("Изменить имя", "Сменить пароль", "Сбросить прогресс", "Удалить аккаунт")
        dialog().setTitle("Настройки").setItems(items) { _, which ->
            when (which) {
                0 -> changeName()
                1 -> changePassword()
                2 -> resetProgress()
                3 -> deleteAccount()
            }
        }.show()
    }

    private fun changeName() {
        val u = Store.current ?: return
        val f = field("Имя", TYPE_NAME, u.name)
        dialog().setTitle("Изменить имя").setView(form(f))
            .setPositiveButton("Сохранить") { _, _ ->
                val n = f.text.toString().trim()
                if (n.length !in 2..20) { toast("Имя: от 2 до 20 символов"); return@setPositiveButton }
                val cur = Store.current ?: return@setPositiveButton
                cur.name = n; Store.save(cur); refresh(); toast("Имя изменено")
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun changePassword() {
        val old = field("Текущий пароль", TYPE_PASSWORD)
        val new = field("Новый пароль (мин. 6 символов)", TYPE_PASSWORD)
        dialog().setTitle("Сменить пароль").setView(form(old, new))
            .setPositiveButton("Сохранить") { _, _ ->
                val u = Store.current ?: return@setPositiveButton
                when {
                    u.passHash != Store.hash(u.email, old.text.toString()) -> toast("Текущий пароль неверный")
                    new.text.length < 6 -> toast("Новый пароль слишком короткий")
                    else -> { Store.resetPassword(u.email, new.text.toString()); toast("Пароль изменён") }
                }
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun resetProgress() {
        dialog().setTitle("Сбросить прогресс?")
            .setMessage("Уровни, звёзды и достижения будут обнулены. Подписка Премиум сохранится.")
            .setPositiveButton("Сбросить") { _, _ ->
                val o = Store.current ?: return@setPositiveButton
                val fresh = User(name = o.name, email = o.email, passHash = o.passHash,
                    premiumUntil = o.premiumUntil, premiumPlan = o.premiumPlan)
                Store.save(fresh); refresh(); toast("Прогресс сброшен")
            }
            .setNegativeButton("Отмена", null).show()
    }

    private fun deleteAccount() {
        dialog().setTitle("Удалить аккаунт?")
            .setMessage("Аккаунт и весь прогресс будут удалены с этого устройства без возможности восстановления.")
            .setPositiveButton("Удалить") { _, _ ->
                val u = Store.current ?: return@setPositiveButton
                Store.delete(u.email); goClear<WelcomeActivity>()
            }
            .setNegativeButton("Отмена", null).show()
    }
}

// ───────────── Премиум ─────────────

class PremiumActivity : AppCompatActivity() {
    private lateinit var btnSubscribe: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Store.current == null) { goClear<WelcomeActivity>(); finish(); return }
        setContentView(R.layout.activity_premium)
        btnSubscribe = findViewById(R.id.btnSubscribe)
        btnSubscribe.setOnClickListener {
            if (Store.current?.isPremium == true) manage() else choosePlan()
        }
        findViewById<TextView>(R.id.tvHaveSub).apply { underline(); setOnClickListener { restore() } }
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val u = Store.current ?: return
        val plan = Plan.byId(u.premiumPlan)
        if (u.isPremium) {
            btnSubscribe.text = "Активен до ${formatDate(u.premiumUntil)}"
            findViewById<TextView>(R.id.tvPrice).text = "${(plan ?: Plan.MONTH).price} ₽"
            findViewById<TextView>(R.id.tvPeriod).text = if (plan == Plan.YEAR) "/ год" else "/ месяц"
        } else {
            btnSubscribe.text = getString(R.string.t_oformit_podpisku)
            findViewById<TextView>(R.id.tvPrice).text = getString(R.string.t_299)
            findViewById<TextView>(R.id.tvPeriod).text = getString(R.string.t_mesyac)
        }
    }

    private fun choosePlan() {
        var selected = 0
        val plans = Plan.values()
        val titles = arrayOf(
            "Месяц — ${Plan.MONTH.price} ₽",
            "Год — ${Plan.YEAR.price} ₽  (выгода 44%)",
        )
        dialog().setTitle("Выберите тариф")
            .setSingleChoiceItems(titles, 0) { _, w -> selected = w }
            .setPositiveButton("Далее") { _, _ -> confirm(plans[selected]) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun confirm(plan: Plan) {
        val u = Store.current ?: return
        dialog().setTitle("Подтверждение оплаты")
            .setMessage("MindQuest Премиум — ${plan.title}\nСумма: ${plan.price} ₽\nСрок: ${plan.days} дней\nАккаунт: ${u.email}\n\n⚠️ Тестовый режим: реальные деньги не списываются.")
            .setPositiveButton("Оплатить ${plan.price} ₽") { _, _ -> pay(plan) }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private fun pay(plan: Plan) {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(24), dp(24), dp(24), dp(24))
            addView(ProgressBar(this@PremiumActivity))
            addView(TextView(this@PremiumActivity).apply {
                text = "Обработка платежа…"; textSize = 16f
                setTextColor(color(R.color.white)); setPadding(dp(16), 0, 0, 0)
            })
        }
        val progress: AlertDialog = dialog().setView(box).setCancelable(false).show()
        // Имитация оплаты: через 1,5 секунды подписка активируется
        Handler(Looper.getMainLooper()).postDelayed({
            if (isFinishing || isDestroyed) return@postDelayed
            progress.dismiss()
            val u = Store.current ?: return@postDelayed
            Premium.activate(u, plan); Store.save(u)
            refresh()
            dialog().setTitle("Премиум активирован! 🎉")
                .setMessage("Спасибо за покупку!\n\nДействует до ${formatDate(u.premiumUntil)}.\n" +
                    "• Безлимитные попытки\n• Категория «Эксклюзив»\n• Без рекламы")
                .setPositiveButton("Отлично", null)
                .show()
        }, 1500)
    }

    private fun manage() {
        val u = Store.current ?: return
        val plan = Plan.byId(u.premiumPlan) ?: Plan.MONTH
        dialog().setTitle("Ваша подписка")
            .setMessage("Тариф: ${plan.title} (${plan.price} ₽)\nАктивна до: ${formatDate(u.premiumUntil)}")
            .setPositiveButton("Продлить") { _, _ -> choosePlan() }
            .setNegativeButton("Отменить подписку") { _, _ -> cancelSub() }
            .setNeutralButton("Закрыть", null)
            .show()
    }

    private fun cancelSub() {
        dialog().setTitle("Отменить Премиум?")
            .setMessage("Безлимитные попытки и категория «Эксклюзив» станут недоступны.")
            .setPositiveButton("Отменить подписку") { _, _ ->
                val u = Store.current ?: return@setPositiveButton
                Premium.cancel(u); Store.save(u); refresh(); toast("Подписка отменена")
            }
            .setNegativeButton("Оставить", null).show()
    }

    private fun restore() {
        val u = Store.current ?: return
        if (u.isPremium) toast("Подписка активна до ${formatDate(u.premiumUntil)}")
        else dialog().setTitle("Подписка не найдена")
            .setMessage("Для аккаунта ${u.email} нет активной подписки. Оформите Премиум, чтобы открыть все возможности.")
            .setPositiveButton("Оформить") { _, _ -> choosePlan() }
            .setNegativeButton("Закрыть", null).show()
    }
}

// ───────────── Игра ─────────────

class QuestionActivity : AppCompatActivity() {
    companion object {
        private const val EXTRA_CAT = "cat"
        fun start(ctx: Context, cat: Category) =
            ctx.startActivity(Intent(ctx, QuestionActivity::class.java).putExtra(EXTRA_CAT, cat.name))
    }

    private lateinit var cat: Category
    private lateinit var puzzles: List<Puzzle>
    private var level = 1
    private var index = 0
    private var correct = 0
    private var mistakes = 0
    private var earned = 0
    private var attempts = 0
    private var hintShown = false

    private lateinit var tvQuestion: TextView
    private lateinit var tvHint: TextView
    private lateinit var etAnswer: EditText
    private lateinit var hearts: List<ImageView>

    private val isDaily get() = cat == Category.DAILY

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val u = Store.current ?: run { goClear<WelcomeActivity>(); finish(); return }
        cat = runCatching { Category.valueOf(intent.getStringExtra(EXTRA_CAT) ?: "") }.getOrDefault(Category.RIDDLES)
        if (cat == Category.PREMIUM && !u.isPremium) { go<PremiumActivity>(); finish(); return }
        if (isDaily && Game.dailyDone(u)) cat = Category.RIDDLES

        setContentView(R.layout.activity_question)
        tvQuestion = findViewById(R.id.tvQuestion)
        tvHint = findViewById(R.id.tvHint)
        etAnswer = findViewById(R.id.etAnswer)
        hearts = listOf(findViewById(R.id.heart1), findViewById(R.id.heart2), findViewById(R.id.heart3))

        level = savedInstanceState?.getInt("level") ?: if (isDaily) 1 else u.currentLevel(cat)
        puzzles = PuzzleBank.level(cat, level)
        savedInstanceState?.let {
            index = it.getInt("index"); correct = it.getInt("correct"); mistakes = it.getInt("mistakes")
            earned = it.getInt("earned"); attempts = it.getInt("attempts"); hintShown = it.getBoolean("hint")
        }

        findViewById<View>(R.id.btnBack).setOnClickListener { confirmExit() }
        onBackPressedDispatcher.addCallback(this) { confirmExit() }
        findViewById<TextView>(R.id.btnAnswer).setOnClickListener { submit() }
        etAnswer.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE) { submit(); true } else false
        }
        findViewById<View>(R.id.btnHint).setOnClickListener { useHint() }
        findViewById<TextView>(R.id.tvHintCost).text = "-${Game.HINT_COST}"

        bind(keepState = savedInstanceState != null)
    }

    override fun onSaveInstanceState(out: Bundle) {
        super.onSaveInstanceState(out)
        out.putInt("level", level); out.putInt("index", index); out.putInt("correct", correct)
        out.putInt("mistakes", mistakes); out.putInt("earned", earned); out.putInt("attempts", attempts)
        out.putBoolean("hint", hintShown)
    }

    private fun bind(keepState: Boolean = false) {
        val q = puzzles[index]
        if (!keepState) { attempts = 0; hintShown = false; etAnswer.setText("") }

        findViewById<TextView>(R.id.tvLevel).text =
            if (isDaily) "Загадка дня" else "Уровень $level · ${index + 1} / ${puzzles.size}"
        findViewById<ProgressBar>(R.id.progress).apply { max = puzzles.size; progress = index + 1 }
        findViewById<TextView>(R.id.tvCategory).text = cat.title
        findViewById<TextView>(R.id.tvReward).text = "+${reward()}"
        findViewById<ImageView>(R.id.ivCategory).apply {
            val (icon, tintColor) = when (cat) {
                Category.LOGIC -> R.drawable.ic_puzzle to R.color.primary
                Category.MATH -> R.drawable.ic_calculator to R.color.green
                Category.PREMIUM -> R.drawable.ic_crown to R.color.yellow
                else -> R.drawable.ic_bulb to R.color.yellow
            }
            setImageResource(icon); tint(color(tintColor))
        }

        tvQuestion.text = q.text
        tvQuestion.textSize = when {
            q.text.length > 140 -> 17f
            q.text.length > 80 -> 20f
            else -> 24f
        }
        tvHint.text = "💡 ${q.hint}"
        tvHint.visibility = if (hintShown) View.VISIBLE else View.GONE
        etAnswer.inputType = if (q.numeric)
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        else InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        updateHearts()

        val u = Store.current
        if (u != null && !u.isPremium) {
            Game.refreshLives(u); Store.save(u)
            if (u.lives <= 0) showNoLives()
        }
    }

    private fun reward() = if (isDaily) Game.DAILY_REWARD else Game.REWARD

    private fun updateHearts() {
        val u = Store.current ?: return
        hearts.forEachIndexed { i, h ->
            h.tint(color(if (u.isPremium || i < u.lives) R.color.heart else R.color.text_muted))
        }
    }

    private fun submit() {
        val input = etAnswer.text.toString()
        if (input.isBlank()) { toast("Введите ответ"); return }
        val u = Store.current ?: return
        if (!u.isPremium) {
            Game.refreshLives(u)
            if (u.lives <= 0) { Store.save(u); showNoLives(); return }
        }
        if (Answers.isCorrect(input, puzzles[index])) onCorrect(u) else onWrong(u)
    }

    private fun onCorrect(u: User) {
        val r = reward()
        u.stars += r; u.totalStars += r; u.solved++
        Store.save(u)
        correct++; earned += r
        toast("Верно! +$r ⭐")
        next()
    }

    private fun onWrong(u: User) {
        attempts++; mistakes++
        if (!u.isPremium) {
            if (u.lives >= Game.MAX_LIVES) u.livesTs = System.currentTimeMillis()
            u.lives = maxOf(0, u.lives - 1)
        }
        Store.save(u)
        updateHearts()
        ObjectAnimator.ofFloat(tvQuestion, "translationX", 0f, 24f, -24f, 16f, -16f, 0f).setDuration(400).start()

        when {
            attempts >= 2 -> revealAnswer()
            !u.isPremium && u.lives <= 0 -> showNoLives()
            else -> toast("Неверно! Попробуйте ещё раз" + if (u.isPremium) "" else " · жизней: ${u.lives}")
        }
    }

    private fun revealAnswer() {
        dialog().setTitle("Неверно 😔")
            .setMessage("Правильный ответ: ${puzzles[index].mainAnswer}")
            .setCancelable(false)
            .setPositiveButton("Дальше") { _, _ -> next() }
            .show()
    }

    private fun useHint() {
        if (hintShown) { toast("Подсказка уже открыта"); return }
        val u = Store.current ?: return
        if (u.stars < Game.HINT_COST) { toast("Недостаточно звёзд для подсказки"); return }
        u.stars -= Game.HINT_COST; u.hintsUsed++
        Store.save(u)
        hintShown = true
        tvHint.visibility = View.VISIBLE
        toast("-${Game.HINT_COST} ⭐")
    }

    private fun next() {
        index++
        if (index < puzzles.size) { bind(); return }
        if (isDaily) finishDaily() else finishLevel()
    }

    private fun finishDaily() {
        val u = Store.current ?: return finish()
        u.dailyDoneDay = Game.today()
        if (correct > 0) u.dailyCount++
        Store.save(u)
        dialog().setTitle(if (correct > 0) "Загадка дня решена! 🎉" else "Загадка дня завершена")
            .setMessage(if (correct > 0) "Вы получили +$earned ⭐ (награда х2).\nНовая загадка — завтра!"
                        else "Ничего страшного! Новая загадка — завтра.")
            .setCancelable(false)
            .setPositiveButton("В меню") { _, _ -> finish() }
            .show()
    }

    private fun finishLevel() {
        val u = Store.current ?: return finish()
        val passed = correct >= Game.PASS_SCORE
        if (passed) {
            u.levels[cat.key] = level
            u.stars += Game.LEVEL_BONUS; u.totalStars += Game.LEVEL_BONUS
            earned += Game.LEVEL_BONUS
            if (mistakes == 0) u.perfectLevels++
        }
        Store.save(u)
        ResultActivity.start(this, cat, level, correct, puzzles.size, mistakes, earned, passed)
        finish()
    }

    private fun showNoLives() {
        val u = Store.current ?: return
        dialog().setTitle("Жизни закончились 💔")
            .setMessage("Новая жизнь через ${Game.formatMs(Game.msToNextLife(u))}.\n\nОформите Премиум, чтобы играть без ограничений.")
            .setCancelable(false)
            .setPositiveButton("Премиум") { _, _ -> go<PremiumActivity>(); finish() }
            .setNegativeButton("В меню") { _, _ -> finish() }
            .show()
    }

    private fun confirmExit() {
        if (isDaily || (index == 0 && attempts == 0)) { finish(); return }
        dialog().setTitle("Выйти из уровня?")
            .setMessage("Прогресс текущего уровня не сохранится. Заработанные звёзды останутся.")
            .setPositiveButton("Выйти") { _, _ -> finish() }
            .setNegativeButton("Играть дальше", null)
            .show()
    }
}

// ───────────── Результат ─────────────

class ResultActivity : AppCompatActivity() {
    companion object {
        fun start(ctx: Context, cat: Category, level: Int, correct: Int, total: Int, mistakes: Int, earned: Int, passed: Boolean) =
            ctx.startActivity(Intent(ctx, ResultActivity::class.java)
                .putExtra("cat", cat.name).putExtra("level", level).putExtra("correct", correct)
                .putExtra("total", total).putExtra("mistakes", mistakes).putExtra("earned", earned)
                .putExtra("passed", passed))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_result)
        val cat = runCatching { Category.valueOf(intent.getStringExtra("cat") ?: "") }.getOrDefault(Category.RIDDLES)
        val level = intent.getIntExtra("level", 1)
        val correct = intent.getIntExtra("correct", 0)
        val total = intent.getIntExtra("total", Game.QUESTIONS_PER_LEVEL)
        val passed = intent.getBooleanExtra("passed", false)

        findViewById<TextView>(R.id.tvLevelTitle).text = "${cat.title} · Уровень $level"
        findViewById<TextView>(R.id.tvResultTitle).text = if (passed) "Уровень пройден!" else "Уровень не пройден"
        findViewById<TextView>(R.id.tvCorrect).text =
            if (passed) "Верно: $correct из $total" else "Верно: $correct из $total\nНужно минимум ${Game.PASS_SCORE}"
        findViewById<TextView>(R.id.tvStarsEarned).text = "+${intent.getIntExtra("earned", 0)}"
        findViewById<TextView>(R.id.tvMistakes).text = intent.getIntExtra("mistakes", 0).toString()
        findViewById<ImageView>(R.id.ivTrophy).tint(color(if (passed) R.color.yellow else R.color.text_muted))

        findViewById<TextView>(R.id.btnNext).apply {
            text = if (passed) getString(R.string.t_sleduyuschiy_uroven) else "Попробовать снова"
            setOnClickListener { QuestionActivity.start(this@ResultActivity, cat); finish() }
        }
        findViewById<TextView>(R.id.btnMenu).setOnClickListener { finish() }
    }
}
