package com.example.mindquest

import android.app.Application
import android.content.Context
import android.content.SharedPreferences
import org.json.JSONObject
import java.security.MessageDigest
import java.util.TimeZone

/** Инициализирует локальное хранилище при старте приложения. */
class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Store.init(this)
    }
}

enum class Category(val key: String, val title: String) {
    RIDDLES("riddles", "Загадка"),
    LOGIC("logic", "Логика"),
    MATH("math", "Математика"),
    PREMIUM("premium", "Эксклюзив"),
    DAILY("daily", "Загадка дня"),
}

/** Аккаунт и прогресс игрока. Хранится локально в SharedPreferences (JSON). */
class User(
    var name: String,
    val email: String,
    var passHash: String,
    var stars: Int = Game.START_STARS,
    var lives: Int = Game.MAX_LIVES,
    var livesTs: Long = System.currentTimeMillis(),
    val levels: MutableMap<String, Int> = mutableMapOf(),
    var solved: Int = 0,
    var hintsUsed: Int = 0,
    var streak: Int = 0,
    var bestStreak: Int = 0,
    var lastActiveDay: Long = -1,
    var dailyDoneDay: Long = -1,
    var dailyCount: Int = 0,
    var premiumUntil: Long = 0,
    var premiumPlan: String = "",
    var totalStars: Int = 0,
    var perfectLevels: Int = 0,
) {
    val isPremium: Boolean get() = premiumUntil > System.currentTimeMillis()

    /** Сколько уровней пройдено в категории. */
    fun passed(c: Category): Int = levels[c.key] ?: 0

    /** Текущий (следующий) уровень в категории, начиная с 1. */
    fun currentLevel(c: Category): Int = passed(c) + 1

    val totalLevel: Int get() = 1 + levels.values.sum()

    fun toJson(): JSONObject = JSONObject().apply {
        put("name", name); put("email", email); put("pass", passHash)
        put("stars", stars); put("lives", lives); put("livesTs", livesTs)
        put("levels", JSONObject(levels.toMap()))
        put("solved", solved); put("hints", hintsUsed)
        put("streak", streak); put("bestStreak", bestStreak); put("lastDay", lastActiveDay)
        put("dailyDay", dailyDoneDay); put("dailyCount", dailyCount)
        put("premiumUntil", premiumUntil); put("premiumPlan", premiumPlan)
        put("totalStars", totalStars); put("perfect", perfectLevels)
    }

    companion object {
        fun fromJson(o: JSONObject): User {
            val lv = mutableMapOf<String, Int>()
            o.optJSONObject("levels")?.let { j -> j.keys().forEach { k -> lv[k] = j.optInt(k) } }
            return User(
                name = o.optString("name"),
                email = o.optString("email"),
                passHash = o.optString("pass"),
                stars = o.optInt("stars", Game.START_STARS),
                lives = o.optInt("lives", Game.MAX_LIVES),
                livesTs = o.optLong("livesTs", System.currentTimeMillis()),
                levels = lv,
                solved = o.optInt("solved"),
                hintsUsed = o.optInt("hints"),
                streak = o.optInt("streak"),
                bestStreak = o.optInt("bestStreak"),
                lastActiveDay = o.optLong("lastDay", -1),
                dailyDoneDay = o.optLong("dailyDay", -1),
                dailyCount = o.optInt("dailyCount"),
                premiumUntil = o.optLong("premiumUntil"),
                premiumPlan = o.optString("premiumPlan"),
                totalStars = o.optInt("totalStars"),
                perfectLevels = o.optInt("perfect"),
            )
        }
    }
}

/** Локальная «база» аккаунтов. Для облака замените реализацию на Firebase/свой сервер. */
object Store {
    private lateinit var prefs: SharedPreferences

    fun init(c: Context) {
        if (!::prefs.isInitialized) prefs = c.applicationContext.getSharedPreferences("mindquest", Context.MODE_PRIVATE)
    }

    private fun all(): JSONObject =
        runCatching { JSONObject(prefs.getString("users", null) ?: "{}") }.getOrDefault(JSONObject())

    private fun key(email: String) = email.trim().lowercase()

    fun find(email: String): User? = all().optJSONObject(key(email))?.let(User::fromJson)

    fun save(u: User) {
        val a = all(); a.put(key(u.email), u.toJson())
        prefs.edit().putString("users", a.toString()).apply()
    }

    fun delete(email: String) {
        val a = all(); a.remove(key(email))
        prefs.edit().putString("users", a.toString()).apply()
        if (currentEmail == key(email)) logout()
    }

    var currentEmail: String?
        get() = prefs.getString("current", null)
        private set(v) { prefs.edit().putString("current", v).apply() }

    val current: User? get() = currentEmail?.let(::find)

    fun hash(email: String, pass: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest("mq:${key(email)}:$pass".toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    /** @return текст ошибки или null при успехе. */
    fun register(name: String, email: String, pass: String): String? {
        if (find(email) != null) return "Аккаунт с таким имейлом уже существует"
        save(User(name = name.trim(), email = key(email), passHash = hash(email, pass)))
        currentEmail = key(email)
        return null
    }

    fun login(email: String, pass: String): Boolean {
        val u = find(email) ?: return false
        if (u.passHash != hash(email, pass)) return false
        currentEmail = key(email)
        return true
    }

    fun resetPassword(email: String, newPass: String): Boolean {
        val u = find(email) ?: return false
        u.passHash = hash(email, newPass); save(u)
        return true
    }

    fun logout() { currentEmail = null }
}

/** Правила игры: жизни, награды, серии, достижения. */
object Game {
    const val START_STARS = 50
    const val MAX_LIVES = 3
    const val LIFE_REGEN_MS = 20 * 60 * 1000L
    const val REWARD = 10
    const val DAILY_REWARD = REWARD * 2
    const val HINT_COST = 5
    const val LEVEL_BONUS = 20
    const val QUESTIONS_PER_LEVEL = 10
    const val PASS_SCORE = 7

    fun today(now: Long = System.currentTimeMillis()): Long =
        (now + TimeZone.getDefault().getOffset(now)) / 86_400_000L

    /** Восстанавливает жизни по таймеру. */
    fun refreshLives(u: User) {
        val now = System.currentTimeMillis()
        if (u.lives >= MAX_LIVES) { u.lives = MAX_LIVES; u.livesTs = now; return }
        val gained = ((now - u.livesTs) / LIFE_REGEN_MS).toInt()
        if (gained > 0) {
            u.lives = minOf(MAX_LIVES, u.lives + gained)
            u.livesTs = if (u.lives >= MAX_LIVES) now else u.livesTs + gained * LIFE_REGEN_MS
        }
    }

    fun msToNextLife(u: User): Long =
        if (u.lives >= MAX_LIVES) 0 else maxOf(0, LIFE_REGEN_MS - (System.currentTimeMillis() - u.livesTs))

    fun formatMs(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    /** Ежедневная серия: вызывается при открытии главного экрана. */
    fun touchStreak(u: User) {
        val t = today()
        if (u.lastActiveDay == t) return
        u.streak = if (u.lastActiveDay == t - 1) u.streak + 1 else 1
        u.bestStreak = maxOf(u.bestStreak, u.streak)
        u.lastActiveDay = t
    }

    fun dailyDone(u: User) = u.dailyDoneDay == today()

    class Achievement(val title: String, val desc: String, val unlocked: (User) -> Boolean)

    val achievements = listOf(
        Achievement("Первый шаг", "Решите первую задачу") { it.solved >= 1 },
        Achievement("Разминка", "Решите 10 задач") { it.solved >= 10 },
        Achievement("Знаток", "Решите 50 задач") { it.solved >= 50 },
        Achievement("Гений", "Решите 200 задач") { it.solved >= 200 },
        Achievement("Без ошибок", "Пройдите уровень без единой ошибки") { it.perfectLevels >= 1 },
        Achievement("Покоритель", "Достигните 10 общего уровня") { it.totalLevel >= 10 },
        Achievement("Звездочёт", "Заработайте 500 звёзд") { it.totalStars >= 500 },
        Achievement("Постоянство", "Заходите 3 дня подряд") { it.bestStreak >= 3 },
        Achievement("Неделя ума", "Заходите 7 дней подряд") { it.bestStreak >= 7 },
        Achievement("Загадка дня", "Решите 5 загадок дня") { it.dailyCount >= 5 },
        Achievement("Логик", "Пройдите 3 уровня логики") { it.passed(Category.LOGIC) >= 3 },
        Achievement("Математик", "Пройдите 3 уровня математики") { it.passed(Category.MATH) >= 3 },
        Achievement("Премиум", "Оформите подписку Премиум") { it.isPremium },
    )
}

/** Тарифы подписки Премиум. */
enum class Plan(val id: String, val title: String, val price: Int, val days: Int) {
    MONTH("month", "Месяц", 299, 30),
    YEAR("year", "Год", 1990, 365);

    companion object {
        fun byId(id: String): Plan? = values().firstOrNull { it.id == id }
    }
}

/** Подписка. Оплата демонстрационная (см. PremiumActivity.pay): деньги не списываются. */
object Premium {
    private const val DAY_MS = 86_400_000L

    /** Активирует или продлевает подписку (срок прибавляется к текущему). */
    fun activate(u: User, plan: Plan) {
        u.premiumUntil = maxOf(System.currentTimeMillis(), u.premiumUntil) + plan.days * DAY_MS
        u.premiumPlan = plan.id
    }

    fun cancel(u: User) {
        u.premiumUntil = 0
        u.premiumPlan = ""
    }
}
