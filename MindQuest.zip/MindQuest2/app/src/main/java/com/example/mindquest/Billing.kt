package com.example.mindquest

import android.app.Activity
import android.os.Handler
import android.os.Looper

enum class Plan(val id: String, val title: String, val price: Int, val days: Int) {
    MONTH("month", "Месяц", 299, 30),
    YEAR("year", "Год", 1990, 365);

    companion object {
        fun byId(id: String): Plan? = values().firstOrNull { it.id == id }
    }
}

/**
 * Платёжный шлюз. Сейчас подключён [DemoPaymentGateway] — он имитирует оплату без списания денег,
 * чтобы приложение полностью работало при установке APK на любое устройство.
 *
 * Для публикации в Google Play: подключите `com.android.billingclient:billing-ktx`,
 * создайте подписки `month` и `year` в Play Console, реализуйте этот интерфейс через BillingClient
 * и присвойте реализацию в [Premium.gateway].
 */
interface PaymentGateway {
    val isTestMode: Boolean
    fun purchase(activity: Activity, plan: Plan, onResult: (success: Boolean, error: String?) -> Unit)
}

object DemoPaymentGateway : PaymentGateway {
    override val isTestMode = true
    override fun purchase(activity: Activity, plan: Plan, onResult: (Boolean, String?) -> Unit) {
        Handler(Looper.getMainLooper()).postDelayed({ onResult(true, null) }, 1500)
    }
}

object Premium {
    var gateway: PaymentGateway = DemoPaymentGateway
    private const val DAY_MS = 86_400_000L

    /** Активирует или продлевает подписку (срок прибавляется к текущему). */
    fun activate(u: User, plan: Plan) {
        val base = maxOf(System.currentTimeMillis(), u.premiumUntil)
        u.premiumUntil = base + plan.days * DAY_MS
        u.premiumPlan = plan.id
    }

    fun cancel(u: User) {
        u.premiumUntil = 0
        u.premiumPlan = ""
    }
}
